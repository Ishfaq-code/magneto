MAGNETO SINGLE CELL — 3MF PRINT PARTS, NO CATCH

Ten printed components: housing, reading plate, lower guide, upper guide,
and six plungers. Print each 3MF once. Catch carrier and pull tab are omitted.
Bought servos, horns and 5 mm steel balls, cardboard shell and 8-cell rail
are excluded. Existing housing geometry is preserved.

Millimeters; each part is centered in X/Y with its bottom at Z=0.
Import into OrcaSlicer with the Centauri Carbon printer selected. These are
individual mesh files, not a sliced project or an arranged print bed.
Check orientations and enable supports where needed before slicing.
No printer profile, material settings or supports are embedded.

Provisional prototype geometry; physical fit and mechanical operation are
not validated. Without the catch, the plungers will not latch raised.
