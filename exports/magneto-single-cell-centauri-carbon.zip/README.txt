CENTAURI CARBON BED LAYOUT

Open BED_LAYOUT_Centauri_Carbon_256x256.3mf in your slicer and select your
Centauri Carbon printer and material profile. It contains all 11 print parts
on one 256 x 256 mm plate, with 20 mm edge margins and 5 mm spacing between
part footprints. All parts start at Z=0; maximum part height is 60 mm.

This is a mesh-only 3MF, not sliced G-code or a saved ELEGOO printer profile.
Keep the relative layout when importing; check bed exclusions, supports,
brims, orientation and toolpaths in the slicer. Support/brim footprints are
not included in the clearance checks. The layout preserves original Z-up
orientation and is not an experimentally validated print orientation.

Use either the bed layout OR individual files, not both in the same job.
See BED_LAYOUT.png for the part map; the individual files remain available.

MAGNETO SINGLE CELL — DRAFT PRINT PARTS

Latest single-cell design: direct insertion cuts in both guide plates,
collar and ball-seat shoulders seated on the guide layers, original right-pull
catch and bottom housing. No guide closing strips or 8-cell rail parts.

Print 11 components: one housing, one reading plate, one lower guide,
one upper guide, one catch carrier, and six ball-seat plungers.
Print each listed file once. The six plungers are equivalent after centering;
you may instead print pin-1 six times.

Choose either the 3MF folder OR the STL folder, not both. They contain the
same parts. All dimensions are millimeters. Files are centered in X/Y and
placed with their lowest point at Z=0. This preserves the modeled Z-up
orientation, not a tested optimal printing orientation. These 3MFs contain
meshes only, with no printer profile, support, material or slicing settings.
Check orientation and supports in your slicer, especially housing overhangs,
plunger cups/collars and catch fingers. PARTS.csv lists dimensions/quantities.

BOUGHT HARDWARE — NOT PRINT FILES
Six SG90 servos and compatible horns, six 5 mm steel balls, ball-seat adhesive,
and suitable housing/lid fasteners. Guide mounting/retention and servo wiring
are not finalized in this prototype. No cardboard shell is included.

ASSEMBLY
With lid and catch removed, slide each plunger sideways through the aligned
cuts in both guides (left stems from the left, right stems from the right).
The collar seats on the lower guide top at 45.4 mm; the ball-seat shoulder
seats on the upper guide top at 55 mm. Install the catch and lid. Model lift
is 2.4 mm; tab travel is 5 mm. Balls are separate bought hardware for gluing.
Gravity reset animation assumes no sticking. Both rest surfaces require
matching printed heights; verify fit and adjust bearing surfaces if needed.

PROTOTYPE STATUS
These are enlarged, provisional fit-test parts, not validated production CAD
or standard-size Braille. Mesh closure and sampled insertion/lift checks pass;
physical assembly, guide retention, printing tolerance, catch flex, gravity
return and servo performance are unvalidated. Check one plunger/guide fit
before committing to a full build.
